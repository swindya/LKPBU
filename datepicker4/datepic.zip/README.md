DCalendar
=========

JQuery calendar plugin plus date picker for input fields.

[Redesigned Branch](https://github.com/dmuy/DCalendar/tree/Material)
